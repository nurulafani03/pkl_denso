<!-- header -->
<?php include 'view/head.php' ?>
<!-- navbar -->
<?php include 'view/navbarHr.php' ?>
<!-- Content -->

<?php
include 'koneksi.php';

$search_keyword = "";
if (isset($_POST['search'])) {
    $search_keyword = $_POST['search_keyword'];
}
?>

<div class="main-content">
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4>Surat Balasan</h4>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Search by Nama or Univ/Sekolah" name="search_keyword" value="<?= $search_keyword ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit" name="search">Search</button>
                        </div>
                    </div>
                </form>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">NIM/NIS</th>
                            <th scope="col">Univ/Sekolah</th>
                            <th scope="col">No.Hp</th>
                            <th scope="col">Surat Pengajuan</th>
                            <th scope="col">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        $query = "SELECT * FROM alternative";
                        if ($search_keyword != "") {
                            $query .= " WHERE merek LIKE '%$search_keyword%' OR tipe LIKE '%$search_keyword%'";
                        }
                        $hasil = $conn->query($query);
                        if ($hasil->num_rows > 0) {
                            while ($row = $hasil->fetch_assoc()) {
                        ?>
                                <tr>
                                    <td><?= $no += 1 ?></td>
                                    <td><?= $row['merek']; ?></td>
                                    <td><?= $row['tipe']; ?></td>
                                    <td><a class="btn btn-danger" onclick="return confirm('data ingin dihapus?');" href="delete_alternative.php?id_pestisida=<?= $row['id_pestisida']; ?>">Delete</a>
                                        <a class="btn btn-primary" href="edit_alternative.php?id_pestisida=<?= $row['id_pestisida'] ?>">Edit</a>
                                    </td>
                                </tr>
                        <?php }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<!-- footer -->
<?php include 'view/footer.php' ?>
