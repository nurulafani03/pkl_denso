<!-- header      -->
<?php include 'view/head.php' ?>
<!-- navbar      -->
<?php include 'view/navbar.php' ?>
<!-- Content -->
<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
   $merek = $_POST['merek'];
   $harga = $_POST['harga'];
   $ukuran = $_POST['ukuran'];
   $hama = $_POST['hama'];
   $kadaluarsa = $_POST['kadaluarsa'];
   $dampak = $_POST['dampak'];

   $hasil = $conn->query("SELECT * FROM penilaian WHERE merek='$merek'");
   if ($hasil->num_rows > 0) {
      echo "<script> alert('merek sudah diinputkan !'); 
      </script>";
   } else {
      $hasil = $conn->query("INSERT INTO penilaian(merek,harga,ukuran,hama,kadaluarsa,dampak) VALUES 
      ('$merek', '$harga', '$ukuran', '$hama', '$kadaluarsa', '$dampak') ");

      if ($hasil) {
         echo "<script> 
         alert('data berhasil diinput');</script>";
      } else {
         echo "<script> alert('gagal input');</script>";
      }
   }
}

?>
<div class="main-content">
   <section class="section">
      <div class="section-header">
         <h1>Penilaian</h1>
      </div>
      <div class="section-body">
         <div class="row">
            <div class="col-lg-8">
               <div class="card">
                  <div class="card-header">
                     <h4>Input Data Penilaian</h4>
                  </div>
                  <div class="card-body">
                     <form action="" method="post">
                        <div class="form-group">
                           <label>Merek Pestisida</label>
                           <select name="merek" class="form-control col-lg-8">
                              <?php $hasil = $conn->query("SELECT merek FROM alternative");
                        while ($row = $hasil->fetch_assoc()) { ?>
                        <option><?= $row['merek']; ?></option>
                        <?php } ?>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Harga</label>
                           <select name="harga" id="" class="form-control col-lg-8">
                              <option>--Silahkan Pilih--</option>
                              <option value="5">(5) < Rp 50.000 </option>
                              <option value="4">(4) Rp.50.000-Rp.100.000</option>
                              <option value="3">(3) Rp.100.000-Rp.300.000 </option>
                              <option value="2">(2) Rp.300.000-Rp.500.000</option>
                              <option value="1">(1) > Rp.500.000</option>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Ukuran Kemasan</label>
                           <select name="ukuran" id="" class="form-control col-lg-8">
                              <option>--Silahkan Pilih--</option>
                              <option value="1">(1) < 50ml </option>
                              <option value="2">(2) 50ml - 100ml </option>
                              <option value="3">(3) 100ml - 300ml </option>
                              <option value="4">(4) 300ml-500ml </option>
                              <option value="5">(5) > 500 ml </option>
                             
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Hama Yang Dibasmi</label>
                           <select name="hama" id="" class="form-control col-lg-8">
                              <option>--Silahkan Pilih--</option>
                              <option value="1">(1) Wareng Batang Coklat </option>
                              <option value="2">(2) Penggerek Batang Padi </option>
                              <option value="3">(3) Tikus Sawah </option>
                              <option value="4">(4) Ulat Grayak </option>
                              <option value="5">(5) Penyakit Hawar Daun </option>
                             
                             
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Daya Tahan Simpan</label>
                           <select name="kadaluarsa" class="form-control col-lg-8">
                              <option>--Silahkan Pilih--</option>
                              <option value="1">(1) < 6 Bulan </option>
                              <option value="2">(2) 6 Bulan - 12 Bulan </option>
                              <option value="3">(3) 1 Tahun - 2 tahun </option>
                              <option value="4">(4) 2 Tahun - 4 Tahun</option>
                              <option value="5">(5) > 4 Tahun </option>
                             
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Dampak terhadap lingkungan</label>
                           <select name="dampak" class="form-control col-lg-8">
                              <option>--Silahkan Pilih--</option>
                              <option value="5">(5) Sangat Baik</option>
                              <option value="4">(4) Baik </option>
                              <option value="3">(3) Cukup</option>
                              <option value="2">(2) Kurang Baik</option>
                              <option value="1">(1) Sangat Tidak Baik </option>
                             
                           </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                     </form>
                  </div>
               </div>
            </div>

            <div class="col-lg-4">
               <div class="card">
                  <div class="card-header">
                     <h4>Bobot Penilaian</h4>
                  </div>
                  <div class="card-body">
                     <table class="table text-center">
                        <thead>
                           <tr>
                              <th scope="col">Bobot</th>
                              <th scope="col">Kepentingan</th>
                           </tr>
                        </thead>

                        <tbody>
                           <tr>
                              <td>(1)</td>
                              <td>Tidak Penting</td>
                           </tr>
                            <tr>
                              <td>(2)</td>
                              <td>Kurang Penting</td>
                           </tr>
                           <tr>
                              <td>(3)</td>
                              <td>Cukup Penting</td>
                           <tr>
                              <td>(4)</td>
                              <td>Penting</td>
                           </tr>
                           <tr>
                              <td>(5)</td>
                              <td>Sangat Penting</td>
                           </tr>
                           
                           </tr>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-header">
                     <h4>Data Penilaian</h4>
                  </div>
                  <div class="card-body">
                     <table class="table">
                        <thead>
                           <tr>
                              <th scope="col">No</th>
                              <th scope="col">Merek</th>
                              <th scope="col">Harga</th>
                              <th scope="col">Ukuran Kemasan</th>
                              <th scope="col">Hama Yang Dibasmi</th>
                              <th scope="col">Daya Tahan Simpan</th>
                              <th scope="col">Dampak Terhadap Lingkungan</th>
                              <th scope="col">Action</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                           $no = 0;
                           $hasil = $conn->query("SELECT * FROM penilaian");
                           if ($hasil->num_rows > 0) {
                              while ($row = $hasil->fetch_assoc()) {
                                 ?>
                                 <tr>
                                    <td><?= $no +=1 ?></td>
                                    <td><?= $row['merek'] ?></td>
                                    <td><?= $row['harga'] ?></td>
                                    <td><?= $row['ukuran'] ?></td>
                                    <td><?= $row['hama'] ?></td>
                                    <td><?= $row['kadaluarsa'] ?></td>
                                    <td><?= $row['dampak'] ?></td>
                                    <td><a class="btn btn-danger btn-flat rounded"
                                  href="delete_penilaian.php?id_penilaian=<?= $row["id_penilaian"];?>" onclick="return confirm('data ingin di hapus?')"><i class="fa fa-trash">/</i></a>
                                  <a class="btn btn-primary  btn-flat rounded" href="edit_penilaian.php?id_penilaian=<?=$row["id_penilaian"]; ?>"><i class= "fa fa-pen"></i></a>

                           </td>
                        </tr>
                        <?php } 
                        } ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
</div>
</section>
</div>

<!-- footeer-->
<?php include 'view/footer.php' ?>