<!-- header -->
<?php include 'view/head.php' ?>
<!-- navbar -->
<?php include 'view/navbarHr.php' ?>
<!-- Content -->

<?php
include 'koneksi.php';
?>

<div class="main-content">
   <section class="section">
      <div class="card">
         <div class="card-header">
            <h4>Permintaan PKL</h4>
         </div>
         <div class="card-body">
            <div class="table-responsive">
               <table class="table table-bordered">
                  <thead>
                     <tr>
                        <th scope="col">No</th>
                        <th scope="col">Kode Permintaan</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Nama Peminta</th>
                        <th scope="col">Section</th>
                        <th scope="col">Pria</th>
                        <th scope="col">Wanita</th>
                        <th scope="col">Level</th>
                        <th scope="col">Jurusan</th>
                        <th scope="col">Keahlian</th>
                        <th scope="col">Tanggal Mulai</th>
                        <th scope="col">Tanggal Selesai</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Aksi</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php
                     $no = 0;
                     $hasil= $conn->query("SELECT * FROM alternative");
                     if($hasil->num_rows > 0){
                        while ($row = $hasil->fetch_assoc()){
                     ?>
                     <tr>
                        <td><?= ++$no ?></td>
                        <td><?= $row['merek']; ?></td>
                        <td><?= $row['tipe']; ?></td>
                        <td>
                           <a class="btn btn-danger btn-sm" onclick="return confirm('data ingin dihapus?');" href="delete_alternative.php?id_pestisida=<?= $row['id_pestisida']; ?>">Delete</a>
                           <a class="btn btn-primary btn-sm" href="edit_alternative.php?id_pestisida=<?= $row['id_pestisida']; ?>">Edit</a>
                        </td>
                     </tr>
                     <?php }
                     } ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </section>
</div>

<!-- footer -->
<?php include 'view/footer.php' ?>
