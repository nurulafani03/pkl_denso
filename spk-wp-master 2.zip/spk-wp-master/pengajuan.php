<!-- header -->
<?php include 'view/head.php' ?>
<!-- navbar -->
<?php include 'view/navbarHr.php' ?>
<!-- Content -->

<?php
include 'koneksi.php';

if (isset($_POST['simpan'])) {
    $merek = $_POST['merek'];
    $tipe = $_POST['tipe'];

    //hasil data
    $hasil = $conn->query("SELECT * FROM alternative WHERE merek='$merek'");
    //cek apakah ada data didalamnya
    if ($hasil->num_rows > 0) {
        echo "<script>
        alert('$merek sudah ditambahkan');
        </script>";
    } else {
        $hasil = $conn->query("INSERT INTO alternative(merek, tipe) VALUES ('$merek', '$tipe')");
        if ($hasil) {
            echo "<script>
                alert('Data berhasil ditambahkan');
            </script>";
        } else {
            echo "<script>
                alert('Gagal input');
            </script>";
        }
    }
}
?>

<div class="main-content">
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4>Input Data PKL</h4>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="merek">Nama</label>
                        <input type="text" class="form-control" id="merek" name="merek" required>
                    </div>
                    <div class="form-group">
                        <label for="tipe">No. HP</label>
                        <input type="text" class="form-control" id="tipe" name="tipe" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Email</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Jenis Kelamin</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">NIM/NIS</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Univ/Sekolah</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Jurusan</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Kepsek/Kaprodi</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">No.Surat</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Referensi</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Kode Permintaan</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Company</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Section</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group">
                        <label for="company">Plant</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <div class="form-group d-flex justify-content-between">
                        <div class="w-50 pr-2">
                            <label for="tglmulai">Tanggal Mulai</label>
                            <input type="date" class="form-control" id="tglmulai" name="tglmulai" required>
                        </div>
                        <div class="w-50 pl-2">
                            <label for="tglselesai">Tanggal Selesai</label>
                            <input type="date" class="form-control" id="tglselesai" name="tglselesai" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="company">Charge BU</label>
                        <input type="text" class="form-control" id="company" name="company" required>
                    </div>
                    <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                </form>
            </div>
        </div>
    </section>
</div>

<!-- footer -->
<?php include 'view/footer.php' ?>
