<!-- header -->
<?php include 'view/head.php' ?>
<!-- navbar -->
<?php include 'view/navbarHr.php' ?>
<!-- Content -->

<?php
include 'koneksi.php';
// Search functionality
$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
    $hasil = $conn->query("SELECT * FROM alternative WHERE merek LIKE '%$search%'");
} else {
    $hasil = $conn->query("SELECT * FROM alternative");
}
?>

<div class="main-content">
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4>Surat Perpanjangan PKL</h4>
            </div>
            <div class="card mt-4">
                <div class="card-header">
                    <form action="" method="POST" class="form-inline">
                        <input type="text" class="form-control mr-2" name="search" placeholder="Search" value="<?= $search ?>" style="font-size: 12px; padding: 4px;">
                        <button type="submit" class="btn btn-primary" style="font-size: 12px; padding: 4px 8px;">Search</button>
                    </form>
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="nama" style="font-size: 12px;">Nama</label>
                            <input type="text" class="form-control" id="merek" name="merek" required disabled style="font-size: 12px; padding: 4px;">
                        </div>
                        <div class="form-group">
                            <label for="no.pkl" style="font-size: 12px;">No. PKL</label>
                            <input type="text" class="form-control" id="tipe" name="tipe" required disabled style="font-size: 12px; padding: 4px;">
                        </div>
                        <div class="form-group">
                            <label for="univ" style="font-size: 12px;">Univ/Sekolah</label>
                            <input type="text" class="form-control" id="company" name="company" required disabled style="font-size: 12px; padding: 4px;">
                        </div>
                        <div class="form-group d-flex justify-content-between">
                            <div class="w-50 pr-2">
                                <label for="tglmulai" style="font-size: 12px;">Tanggal Mulai</label>
                                <input type="date" class="form-control" id="tglmulai" name="tglmulai" required disabled style="font-size: 12px; padding: 4px;">
                            </div>
                            <div class="w-50 pl-2">
                                <label for="tglselesai" style="font-size: 12px;">Tanggal Selesai</label>
                                <input type="date" class="form-control" id="tglselesai" name="tglselesai" required disabled style="font-size: 12px; padding: 4px;">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" name="create" style="font-size: 12px; padding: 4px 8px;">create</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- footer -->
<?php include 'view/footer.php' ?>