<!-- header      -->
<?php include 'view/head.php' ?>
<!-- navbar      -->
<?php include 'view/navbar.php' ?>
<!-- Content -->
<?php
include 'koneksi.php';

if(isset($_POST['edit'])) {
   $get_id_penilaian= $_GET['id_penilaian'];
   $merek= $_POST['merek'];
   var_dump($merek);
   $harga= $_POST['harga'];
   $ukuran= $_POST['ukuran'];
   $hama= $_POST['hama']; 
   $kadaluarsa= $_POST['kadaluarsa'];
   $dampak= $_POST['dampak'];

   $hasil= $conn->query("UPDATE penilaian SET merek='$merek',harga='$harga', ukuran='$ukuran', hama='$hama', kadaluarsa='$kadaluarsa', dampak='$dampak' WHERE id_penilaian='$get_id_penilaian'");
   if($hasil){
      echo "<script>
         alert('data berhasil di edit!');
         window.location.href='penilaian.php';
      </script>";
   } else{
      echo"<script>
      alert('gagal diedit!');
      </script>";
   }
}


?>
<div class="main-content">
   <section class="section">
      <div class="section-header">
         <h1>Penilaian</h1>
      </div>
      <div class="section-body">
         <div class="row">
            <div class="col-lg-10">
               <div class="card">
                  <div class="card-header">
                     <h4>Edit Data Penilaian</h4>
                  </div>
                  <div class="card-body">
                     <form action="" method="post">
                        <?php
                        $id_penilaian= $_GET['id_penilaian'];
                        $hasil= $conn->query("SELECT *FROM penilaian WHERE id_penilaian=$id_penilaian");
                        if($hasil->num_rows>0){
                           $row= $hasil-> fetch_assoc();
                        ?>   
                        <div class="form-group">
                           <label>Merek Pestisida</label>
                           <input type="text" name="merek" class="form-control col-lg-8" value="<?=$row['merek'];?>">
                        </div>
                        <div class="form-group">
                           <label>Harga</label>
                           <select name="harga" id="" class="form-control col-lg-8">
                              <option><?= $row['harga'];?></option>
                              <option value="5">(5) Rp.1.000.000 - Rp. 1.999.000</option>
                              <option value="4">(4) Rp.2.000.000 - Rp. 4.999.000</option>
                              <option value="3">(3) Rp.5.000.000 - Rp. 7.999.000</option>
                              <option value="2">(2) Rp.8.000.000 - Rp. 9.999.000</option>
                              <option value="1">(1) > Rp.10.000.000</option>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Ukuran kemasan </label>
                           <select name="ukuran" id="" class="form-control col-lg-8">
                              <option><?= $row['ukuran'];?></option>
                              <option value="1">(1) < 50ml </option>
                              <option value="2">(2) 50ml - 100ml</option>
                              <option value="3">(3) 100ml - 300ml</option>
                              <option value="4">(4) 300ml - 500ml</option>
                              <option value="5">(5) >500ml </option>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Hama Yang Dibasmi</label>
                           <select name="hama" id="" class="form-control col-lg-8">
                              <option><?= $row['hama'];?></option>
                              <option value="1">(1) Wareng Batang Coklat </option>
                              <option value="2">(2) Penggerek Batang Padi </option>
                              <option value="3">(3) Tikus Sawah </option>
                              <option value="4">(4) Ulat Grayak </option>
                              <option value="5">(5) Penyakit Hawar Daun </option>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Daya Tahan Simpan</label>
                           <select name="kadaluarsa" class="form-control col-lg-8">
                              <option><?= $row['kadaluarsa'];?></option>
                              <option value="1">(1) < 6 Bulan </option>
                              <option value="2">(2) 6 Bulan - 12 Bulan </option>
                              <option value="3">(3) 1 Tahun - 2 Tahun </option>
                              <option value="4">(4) 2 Tahun - 4 Tahun </option>
                              <option value="5">(5) > 4 Tahun </option>
                           </select>
                        </div>
                        <div class="form-group">
                           <label>Dampak Terhadap Lingkungan</label>
                           <select name="dampak" class="form-control col-lg-8">
                              <option><?= $row['dampak'];?></option>
                              <option value="5">(5) Sangat Baik </option>
                              <option value="4">(4) Baik </option>
                              <option value="3">(3) Cukup</option>
                              <option value="2">(2) Kurang Baik </option>
                              <option value="1">(1) Sangat Tidak Baik</option>
                           </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="edit">simpan</button>
                        <?php } ?>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>

<!-- footeer-->
<?php include 'view/footer.php' ?>