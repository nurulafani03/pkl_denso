<div id="app">
    <div class="main-wrapper">
        <div class="navbar-bg"></div>
        <nav class="navbar navbar-expand-lg main-navbar">
            <form class="form-inline mr-auto">
                <ul class="navbar-nav mr-3">
                    <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
                    <li><a href="#" data-toggle="search" class="nav-link nav-link-lg d-sm-none"><i class="fas fa-search"></i></a></li>
                </ul>
            </form>
            <ul class="navbar-nav navbar-right">
                <li class="dropdown">
                    <a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                        <img alt="image" src="assets/template/assets/img/avatar/avatar-1.png" class="rounded-circle mr-1">
                        <div class="d-sm-none d-lg-inline-block">User</div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <div class="dropdown-title">Nama User</div>
                        <a href="profil.php" class="dropdown-item has-icon">
                            <i class="far fa-user"></i> Profile
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <div class="main-sidebar">
            <aside id="sidebar-wrapper">
                <div class="sidebar-brand">
                    <a href="wp.php">PT. Denso Indonesia</a>
                </div>
                <div class="sidebar-brand sidebar-brand-sm">
                    <a href="wp.php">HR</a>
                </div>
                <ul class="sidebar-menu">
                    <li class="menu-header">Dashboard</li>
                    <li><a class="nav-link" href="index.php"><i class="fas fa-fire"></i> <span>Dashboard</span></a></li>
                    
                    <li class="menu-header">
                     
                    </li>
                    <li><a class="nav-link" href="data.php"><i class="fas fa-database"></i> <span>Data PKL</span></a></li>
                    
                    <li class="menu-header">Permintaan PKL</li>
                    <li><a class="nav-link" href="permintaan.php"><i class="fas fa-clipboard-list"></i> <span>Permintaan PKL</span></a></li>
                    
                    <li class="menu-header">Pengajuan PKL</li>
                    <li><a class="nav-link" href="pengajuan.php"><i class="fas fa-file-alt"></i> <span>Pengajuan PKL</span></a></li>
                    
                    <li class="menu-header">Surat Balasan</li>
                    <li><a class="nav-link" href="balasan.php"><i class="fas fa-envelope"></i> <span>Surat Balasan</span></a></li>
                    
                    <li class="menu-header">Surat Perpanjangan</li>
                    <li><a class="nav-link" href="perpanjangan.php"><i class="fas fa-calendar-alt"></i> <span>Surat Perpanjangan</span></a></li>
                    
                    <li class="menu-header">Log Out</li>
                    <li><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Log Out</span></a></li>
                </ul>
            </aside>
        </div>
    </div>
</div>
