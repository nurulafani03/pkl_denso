<!-- header -->
<?php include 'view/head.php' ?>
<!-- navbar -->
<?php include 'view/navbarHr.php' ?>
<!-- Content -->

<?php
include 'koneksi.php';

// Search functionality
$search = '';
if (isset($_POST['search'])) {
    $search = $_POST['search'];
    $hasil = $conn->query("SELECT * FROM alternative WHERE merek LIKE '%$search%'");
} else {
    $hasil = $conn->query("SELECT * FROM alternative");
}

if(isset($_POST['simpan'])){
    $merek= $_POST['merek'];
    $tipe= $_POST['tipe'];

    //hasil data
    $hasil= $conn-> query ("SELECT * FROM alternative WHERE merek='$merek'");
    //cek apakah ada data didalamnya
    if ($hasil-> num_rows>0){
        echo "<script>
        alert('$merek sudah ditambahkan');
        </script>";
    } else {
        $hasil= $conn-> query("INSERT INTO alternative(merek, tipe) VALUES ('$merek', '$tipe')");
        if($hasil){
            echo "<script>
                alert('Data berhasil ditambahkan');
            </script>";
        } else {
            echo "<script>
                alert('Gagal input');
            </script>";
        }
    }
}
?>

<div class="main-content">
    <section class="section">
        <div class="card">
            <div class="card-header">
                <h4>Data PKL</h4>
            </div>
            <div class="card-body">
                <form action="" method="POST" class="form-inline mb-3">
                    <input type="text" class="form-control mr-2" name="search" placeholder="Search" value="<?= $search ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Section</th>
                                <th scope="col">Company</th>
                                <th scope="col">Tanggal Mulai</th>
                                <th scope="col">Tanggal Selesai</th>
                                <th scope="col">Detail Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 0;
                            if($hasil -> num_rows > 0){
                                while ($row = $hasil-> fetch_assoc()){
                            ?>
                            <tr>
                                <td><?= ++$no ?></td>
                                <td><?= $row['merek'];?></td>
                                <td><?= $row['tipe'];?></td>
                                <td>
                                    <a class="btn btn-danger btn-sm" onclick="return confirm ('data ingin dihapus?');" href="delete_alternative.php?id_pestisida=<?= $row['id_pestisida']; ?>">Delete</a>
                                    <a class="btn btn-primary btn-sm" href="edit_alternative.php?id_pestisida=<?= $row['id_pestisida']?>">Edit</a>
                                </td>
                            </tr>
                            <?php }
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- footer -->
<?php include 'view/footer.php' ?>
