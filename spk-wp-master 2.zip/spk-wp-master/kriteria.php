<!-- footeer      -->
<?php include 'view/head.php' ?>
<!-- footeer      -->
<?php include 'view/navbar.php' ?>
<!-- Content -->
<?php
include 'koneksi.php';

if(isset($_POST['simpan'])){
   $harga= $_POST['harga'];
   $ukuran= $_POST['ukuran'];
   $hama= $_POST['hama'];
   $kadaluarsa= $_POST['kadaluarsa'];
   $dampak= $_POST['dampak'];
   
   $hasil= $conn->query("SELECT * FROM kriteria");
   if($hasil->num_rows>0){
      echo "<script> alert('bobot sudah ada!');</script>";
   } else {
      $hasil= $conn->query("INSERT INTO kriteria (harga,ukuran,hama,kadaluarsa,dampak)VALUES ('".$harga. "','" . $ukuran."','" .$hama."','" .$kadaluarsa."','" .$dampak."' )");
      if($hasil){
         echo "<script> alert('data berhasil diinput');</script>";
      } else{
         echo"<script>alert('gagal input');</script>";
      }
   }
}

?>
<div class="main-content">
   <section class="section">
      <div class="section-header">
         <h1>Kriteria</h1>
      </div>
      <div class="section-body">
         <div class="row">
            <div class="col-md-6 col-lg-6"> 
               <div class="card">
                  <div class="card-header">
                     <h4>Input Bobot Kriteria</h4>
                  </div>
                  <div class="card-body">
                     <form action="" method="POST">
                        <div class="form-group row">
                           <label class="col-lg-4 col-form-label">Harga</label>
                           <div class="col-lg-4">
                              <input type="text" class="form-control" autocomplete="off" name="harga" required>
                           </div>
                        </div>
                        <div class="form-group row">
                           <label class="col-lg-4 col-form-label">Ukuran Kemasan</label>
                           <div class="col-lg-4">
                              <input type="text" class="form-control" name="ukuran" autocomplete="off" required>
                           </div>
                        </div>
                        <div class="form-group row">
                           <label class="col-lg-4 col-form-label">Hama Yang Dibasmi</label>
                           <div class="col-lg-4">
                              <input type="text" class="form-control" name="hama" autocomplete="off" required>
                           </div>
                        </div>
                        <div class="form-group row">
                           <label class="col-lg-4 col-form-label">Daya Tahan Simpan</label>
                           <div class="col-lg-4">
                              <input type="text" class="form-control" name="kadaluarsa" autocomplete="off" required>
                           </div>
                        </div>
                        <div class="form-group row">
                           <label class="col-lg-4 col-form-label">Dampak Terhadap Lingkungan</label>
                           <div class="col-lg-4">
                              <input type="text" class="form-control" name="dampak" autocomplete="off" required>
                           </div>
                        </div>
                        <button class="btn btn-primary" name="simpan" type="submit">Simpan</button>
                     </form>
                  </div>
               </div>
            </div>

            <div class="col-md-6 col-lg-6">
               <div class="card">
                  <div class="card-header">
                     <h4>Data Bobot</h4>
                  </div>

                  <div class="card-body ">
                     <table class="table text-center">
                        <thead>
                           <tr>
                              <th scope="col">Bobot</th>
                              <th scope="col">Kepentingan</th>
                           </tr>
                        </thead>

                        <tbody>
                           <tr>
                              <td>1</td>
                              <td>Tidak Penting</td>
                           </tr>
                            <tr>
                              <td>2</td>
                              <td>Kurang Penting</td>
                           </tr>
                           <tr>
                              <td>3</td>
                              <td>Cukup Penting</td>
                           </tr>
                           <tr>
                              <td>4</td>
                              <td>Penting</td>
                           </tr>
                           <tr>
                              <td>5</td>
                              <td>Sangat Penting</td>
                           </tr>
                        </tbody>
                     </table>
                  </div>

               </div>
               
            </div>
         </div>
         <div class="row">
            <div class="col-lg-12">
               <div class="card">
                  <div class="card-header">
                     <h4>Data Bobot</h4>
                  </div>
                  <div class="card-body">
                     <table class="table">
                        <thead>
                           <tr>
                              <th scope="col">No</th>
                              <th scope="col">Harga</th>
                              <th scope="col">Ukuran Kemasan</th>
                              <th scope="col">Hama Yang Dibasmi</th>
                              <th scope="col">Daya Tahan Simpan</th>
                              <th scope="col">Dampak Yang Diberikan Terhadap Lingkungan</th>
                         <!--      <th scope="col">Normalisasi</th> -->
                              <th scope="col">action</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                           $no = 0;
                           $hasil= $conn->query("SELECT* FROM kriteria"); 
                           while ($row= $hasil ->fetch_assoc()) { ?>
                              <tr>
                                 <td><?= $no=+1?></td>
                                 <td><?= $row['harga']?></td>
                                 <td><?= $row['ukuran']?></td>
                                 <td><?= $row['hama']?></td>
                                 <td><?= $row['kadaluarsa']?></td>
                                 <td><?= $row['dampak']?></td>
                         <!--         <td><?= $row['dampak']?></td> -->
                                 <td>
                                    <a onclick="return confirm ('data ingin di hapus?');" class="btn btn-danger" href="delete_kriteria.php?id_kriteria= <?=$row['id_kriteria'];?>">Delete</a>
                                 </td>
                              </tr>
                              <?php }?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</div>

<!-- footeer-->
<?php include 'view/footer.php' ?>